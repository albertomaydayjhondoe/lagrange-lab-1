-- Academia abierta: cualquier usuario autenticado puede unirse
-- INSTANTÁNEAMENTE a una academia pública, sin aprobación de un admin.
--
-- Seguridad: el usuario SOLO puede insertarse a sí mismo (user_id =
-- auth.uid()), SOLO con role = 'member' (nunca owner/admin/platon), y
-- SOLO si la academia destino tiene is_public = true. Las academias
-- privadas siguen requiriendo el flujo de access_requests existente,
-- que esta migración no toca.

DROP POLICY IF EXISTS "Users can self-join public academies" ON public.academy_members;

CREATE POLICY "Users can self-join public academies"
ON public.academy_members
FOR INSERT
TO authenticated
WITH CHECK (
  user_id = auth.uid()
  AND role = 'member'
  AND EXISTS (
    SELECT 1 FROM public.academies
    WHERE academies.id = academy_members.academy_id
    AND academies.is_public = true
  )
);

-- Índice para que /academias liste rápido las academias públicas a
-- medida que crezcan.
CREATE INDEX IF NOT EXISTS idx_academies_is_public
ON public.academies (is_public)
WHERE is_public = true;

-- Asegura que cualquier usuario autenticado (miembro o no) pueda ver
-- los datos básicos de academias públicas para poder descubrirlas y
-- unirse — sin esto, /academias no podría listar nada para un usuario
-- que aún no es miembro de ninguna.
DROP POLICY IF EXISTS "Anyone authenticated can view public academies" ON public.academies;

CREATE POLICY "Anyone authenticated can view public academies"
ON public.academies
FOR SELECT
TO authenticated
USING (
  is_public = true
  OR EXISTS (
    SELECT 1 FROM public.academy_members
    WHERE academy_members.academy_id = academies.id
    AND academy_members.user_id = auth.uid()
  )
);
