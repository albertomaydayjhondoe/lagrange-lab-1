-- RAG semántico real: función RPC que hace búsqueda por distancia coseno
-- sobre corpus_fragments.embedding usando pgvector. Hasta ahora
-- corpusRetrieval.ts solo filtraba por eje/keyword; los embeddings ya
-- generados por ingest-source nunca se usaban para buscar.

CREATE OR REPLACE FUNCTION public.match_corpus_fragments(
  query_embedding vector(1536),
  match_academy_id uuid,
  match_count int DEFAULT 3
)
RETURNS TABLE (
  id uuid,
  content text,
  axis text[],
  tension numeric,
  source_file text,
  academy_id uuid,
  similarity float
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    cf.id,
    cf.content,
    cf.axis,
    cf.tension,
    cf.source_file,
    cf.academy_id,
    1 - (cf.embedding <=> query_embedding) AS similarity
  FROM public.corpus_fragments cf
  WHERE (cf.academy_id = match_academy_id OR cf.academy_id IS NULL)
    AND cf.embedding IS NOT NULL
    AND cf.status = 'active'
  ORDER BY cf.embedding <=> query_embedding
  LIMIT match_count;
$$;

-- Nota de seguridad: esta función es SECURITY DEFINER (necesario para
-- que el cálculo de distancia vectorial no dependa de qué RLS tenga
-- conectado el llamante), pero el aislamiento entre academias se
-- mantiene porque el WHERE exige coincidencia exacta con
-- match_academy_id (o fragmentos globales academy_id IS NULL). El
-- LLAMANTE (la edge function) es responsable de pasar el academy_id
-- correcto tras validar membresía — esta función no valida membresía
-- por sí misma, solo aísla datos por el parámetro recibido.

REVOKE ALL ON FUNCTION public.match_corpus_fragments(vector, uuid, int) FROM public;
GRANT EXECUTE ON FUNCTION public.match_corpus_fragments(vector, uuid, int) TO authenticated, service_role;
