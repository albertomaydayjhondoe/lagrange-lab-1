/**
 * Generación de embeddings compartida.
 *
 * Extraído de ingest-source/index.ts para que cualquier function que
 * necesite generar el embedding de un texto (para insertarlo o para
 * buscar por similitud) use exactamente el mismo modelo y endpoint.
 */

const AI_GATEWAY_URL = (Deno.env.get("AI_GATEWAY_URL") ?? "https://api.openai.com/v1").replace(/\/$/, "");
const AI_EMBEDDING_MODEL = Deno.env.get("AI_EMBEDDING_MODEL") ?? "text-embedding-3-small";

/**
 * Genera el embedding de un texto. Devuelve null (nunca lanza) si falla
 * — el caller debe degradar con gracia a búsqueda por eje/keyword si no
 * hay embedding disponible, en vez de romper la respuesta al usuario.
 */
export async function getEmbedding(text: string, apiKey: string): Promise<number[] | null> {
  try {
    const response = await fetch(`${AI_GATEWAY_URL}/embeddings`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: AI_EMBEDDING_MODEL,
        input: text.substring(0, 8000),
      }),
    });

    if (!response.ok) {
      console.warn(`getEmbedding: API error ${response.status}`);
      return null;
    }

    const data = await response.json();
    return data.data[0].embedding;
  } catch (err) {
    console.warn("getEmbedding: unexpected error", err);
    return null;
  }
}
