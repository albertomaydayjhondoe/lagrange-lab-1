import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

// Vercel inyecta la variable de entorno VERCEL=1 automáticamente durante
// el build. GitHub Pages sirve el sitio desde una subruta
// (github.io/lagrange-lab-1/), Vercel desde la raíz del dominio — si se
// deja "/lagrange-lab-1/" fijo, el build en Vercel pide todos los
// assets en una ruta que no existe y la página queda en blanco.
const isVercel = process.env.VERCEL === "1";

export default defineConfig({
  base: isVercel ? "/" : "/lagrange-lab-1/",
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
});
